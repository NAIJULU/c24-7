<?php if (!defined('W3TC')) die(); ?>
<?php $this->checkbox('minify.htmltidy.options.clean', false, 'html_') ?> <?php _e('Clean', 'w3-total-cache'); ?></label><br />
<?php $this->checkbox('minify.htmltidy.options.hide-comments', false, 'html_') ?> <?php _e('Hide comments', 'w3-total-cache'); ?></label><br />
